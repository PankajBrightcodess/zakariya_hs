  <div class="text-right">
          <div class="credits">
                
                <a href="http://www.bookmysyllabus.com/">bookmysyllabus</a> by <a href="http://rsgss.com/">RSG Software Services Pvt. Ltd.</a>
            </div>
        </div>